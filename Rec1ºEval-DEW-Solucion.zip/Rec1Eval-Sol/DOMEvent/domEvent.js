const dataName = document.getElementById('data-name');
const dataDescrip = document.getElementById('data-description');
const menuCateg = document.getElementById('panel-categories');
const gamesList = document.getElementById('games-list');
const gamesCount = document.getElementById('games-count');
const playedHours = document.getElementById('playedHours');

//- Encabezados
dataName.textContent = data.name;
dataDescrip.textContent = data.description;

//- Menú Dinámico + Carga Inicial
const btnTodas = document.createElement('button');
btnTodas.textContent = 'Todas';
btnTodas.addEventListener('click', function() {
        //- Contador (total de juegos)
        gamesCount.textContent = data.games.length;
        //- Total Horas (total de juegos)
            playedHours.textContent = totalHours(data.games);
    renderGames(data.games);
});
menuCateg.appendChild(btnTodas);

//- Filtrado
data.categories.forEach(function(category) {
    const button = document.createElement('button');
    button.textContent = category;
    button.id = category;

    button.addEventListener('click', function () {
        const filterGames = data.games.filter( function (game) {
            return game.category === category;
        });
            //- Contador (por categoria)
            gamesCount.textContent = filterGames.length;
            //- Total Horas (por categoria)
            playedHours.textContent = totalHours(filterGames);
        renderGames(filterGames);
    });

    menuCateg.appendChild(button);
});

//- Renderizado + Validacion Estado
function renderGames(games) {
    gamesList.innerHTML = '';

    games.forEach(game => {
        const li = document.createElement('li');
        li.textContent = game.title;
        if (game.completed) {
            li.classList.add('completed');
        }
        //- Info Extra
        li.addEventListener('mouseover', function () {
            console.log("Juego: %s - Horas Jugadas: %d",game.title,game.playedHours);
        });
        gamesList.appendChild(li);
    });
}

function totalHours(games){
    let total = 0;
    games.forEach( function(game) {
        total += game.playedHours;
    });
    return total;
}

renderGames(data.games);

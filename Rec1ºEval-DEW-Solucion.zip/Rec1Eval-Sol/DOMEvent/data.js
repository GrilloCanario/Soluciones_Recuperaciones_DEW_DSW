const data = {
    name: "Datos de Videojuegos",
    description: "Conjunto de datos que contiene información sobre varios videojuegos, incluyendo su título, género, plataforma, fecha de lanzamiento y calificación.",
    categories: [
        "Acción",
        "Aventura",
        "RPG",
        "Estrategia",
        "Deportes",
        "Puzzle",
        "Simulación"
    ],
    games: [
        {
            title: "The Legend of Zelda: Breath of the Wild",
            category: "Aventura",
            completed: true,
            playedHours: 120
        },
        {
            title: "God of War",
            category: "Acción",
            completed: true,
            playedHours: 80
        },
        {
            title: "Stardew Valley",
            category: "Simulación",
            completed: false,
            playedHours: 45
        },
        {
            title: "FIFA 21",
            category: "Deportes",
            completed: false,
            playedHours: 30
        },
        {
            title: "Minecraft",
            category: "Simulación",
            completed: true,
            playedHours: 150
        },
        {
            title: "Elden Ring",
            category: "Acción",
            completed: true,
            playedHours: 95
        },
        {
            title: "The Witcher 3",
            category: "RPG",
            completed: true,
            playedHours: 110
        },
        {
            title: "Civilization VI",
            category: "Estrategia",
            completed: false,
            playedHours: 75
        },
        {
            title: "Dark Souls III",
            category: "Acción",
            completed: true,
            playedHours: 105
        },
        {
            title: "Final Fantasy VII Remake",
            category: "RPG",
            completed: true,
            playedHours: 85
        },
        {
            title: "Fortnite",
            category: "Acción",
            completed: false,
            playedHours: 200
        },
        {
            title: "Hollow Knight",
            category: "Aventura",
            completed: true,
            playedHours: 40
        },
        {
            title: "XCOM 2",
            category: "Estrategia",
            completed: false,
            playedHours: 0
        },
        {
            title: "Red Dead Redemption 2",
            category: "Aventura",
            completed: true,
            playedHours: 130
        },
        {
            title: "Cyberpunk 2077",
            category: "RPG",
            completed: false,
            playedHours: 55
        },
        {
            title: "Assassin's Creed Valhalla",
            category: "Acción",
            completed: false,
            playedHours: 60
        },
        {
            title: "The Last of Us Part II",
            category: "Aventura",
            completed: true,
            playedHours: 30
        },
        {
            title: "Persona 5",
            category: "RPG",
            completed: true,
            playedHours: 100
        },
        {
            title: "Overwatch",
            category: "Acción",
            completed: false,
            playedHours: 150
        },
        {
            title: "The Elder Scrolls V: Skyrim",
            category: "RPG",
            completed: true,
            playedHours: 200
        },
        {
            title: "Rocket League",
            category: "Deportes",
            completed: true,
            playedHours: 120
        },
        {
            title: "Cities: Skylines",
            category: "Simulación",
            completed: false,
            playedHours: 80
        },
        {
            title: "Monster Hunter: World",
            category: "Acción",
            completed: true,
            playedHours: 90
        },
        {
            title: "Hades",
            category: "RPG",
            completed: true,
            playedHours: 50
        },
        {
            title: "Farming Simulator 19",
            category: "Simulación",
            completed: false,
            playedHours: 20
        },
    ]
};

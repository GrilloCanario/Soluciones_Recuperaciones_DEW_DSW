//- Clase Padre
class Vehiculo {
    constructor(marca,modelo){
        this.marca = marca;
        this.modelo = modelo;
    }
    describir(){
        return `Vehiculo:[${this.marca}][${this.modelo}].`;
    }    
}

//- Clase Hija 1
class Coche extends Vehiculo {
    constructor(marca,modelo,numPuertas){
        super(marca,modelo);
        this.numPuertas = numPuertas;
    }
    describir(){
        return `Coche: ${super.describir()} con ${this.numPuertas} puertas.`;
    }
    abrirMaletero(){
        return `El maletero del coche se ha abierto.`;
    }
}

//- Clase Hija 2
class Moto extends Vehiculo {
    constructor(marca,modelo,cilindrada){
        super(marca,modelo);
        this.cilindrada = cilindrada;
    }
    describir(){
        return `Moto: ${super.describir()} de ${this.cilindrada}cc.`;
    }
    hacerCaballito(){
        return `!Andres y Juanka hacen caballitos con sus motos de juguete!.`;
    }
}
//- Instanciación y Almacenamiento
const veh1 = new Coche("Honda","A1",5);
const veh2 = new Coche("Seat","A2",4);
const veh3 = new Moto("Susuki","B1",400);
const veh4 = new Moto("Yamaha","B2",800);
const miFlota = [veh1,veh2,veh3,veh4];

//- Salida
miFlota.forEach((flota) => {
    if(flota instanceof Coche) {
        console.log(flota.describir() + flota.abrirMaletero());
    } else {
        console.log(flota.describir() + flota.hacerCaballito());
    }
})

const PISTAS = [
    { id: 1, nombre: "Pista de Tenis 1", precio: 10 },
    { id: 2, nombre: "Pista de Tenis 2", precio: 10 },
    { id: 3, nombre: "Pista de Pádel Cristal", precio: 15 },
    { id: 4, nombre: "Pabellón Fútbol Sala", precio: 25 },
    { id: 5, nombre: "Pista de Baloncesto", precio: 20 },
    { id: 6, nombre: "Pista de Vóley Playa", precio: 18 },
    { id: 7, nombre: "Pista de Squash", precio: 12 },
    { id: 8, nombre: "Pista de Badminton", precio: 14 },
    { id: 9, nombre: "Pista de Fútbol 7", precio: 22 }
];
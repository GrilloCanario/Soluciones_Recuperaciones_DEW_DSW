const selectPista = document.getElementById('pista');

const inputHoraInicio = document.getElementById('horaInicio');
const inputHoraFin = document.getElementById('horaFin');

const checkSocio = document.getElementById('esSocio');

const divEmail = document.getElementById('grupoEmail');
const inputEmail = document.getElementById('email');

const divSocio = document.getElementById('grupoSocio');
const inputSocio = document.getElementById('numSocio');

//- Carga Dinamica
PISTAS.forEach(pista => {
    const option = document.createElement('option');
    option.value = pista.id;
    option.textContent = `${pista.nombre} | Precio: ${pista.precio}€`;
    selectPista.appendChild(option);
});

//- Gestion de Socio
checkSocio.addEventListener('change', () => {
    if(checkSocio.checked) {
        divSocio.classList.remove('oculto');
        divEmail.classList.add('oculto');
            inputSocio.required = true;
            inputEmail.required = false;
            inputEmail.value = "";
    } else {
        divSocio.classList.add('oculto');
        divEmail.classList.remove('oculto');
            inputSocio.required = false;
            inputEmail.required = true;
            inputSocio.value = "";
    }
});

//- Validacion Horas
function checkTime() {
    if (inputHoraInicio.value && inputHoraFin.value) {
        if (inputHoraFin.value <= inputHoraInicio.value) {
            inputHoraFin.setCustomValidity("La hora de fin no puede ser igual o anterior a la hora de inicio");
        } else {
            inputHoraFin.setCustomValidity("");
        }
    } else {
        inputHoraFin.setCustomValidity("");
    }
}
inputHoraInicio.addEventListener('input', checkTime);
inputHoraFin.addEventListener('input', checkTime);

inputHoraInicio.addEventListener('input', checkTime);
inputHoraFin.addEventListener('input', checkTime);
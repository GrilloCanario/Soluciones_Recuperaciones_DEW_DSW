<?php
require_once "datos.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <h2>Introducir Nota</h2>
    <form action="procesar_notas.php" method="post">
        <p>
            <label for="name">Alumno</label>
            <select name="alumno" id="alumno" >
                <option value="">Selecciona</option>
                <?php foreach ($notasAlumnos as $nombre => $notas): ?>
                    <option value="<?= $nombre ?>">
                        <?= $nombre ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </p>
        <p>
            <label for="nota">Nota:</label>
            <input type="number" name="nota" id="nota" step="0.01" >
        </p>
        <p>
            <button type="submit">Enviar</button>
        </p>
    </form>
</body>

</html>
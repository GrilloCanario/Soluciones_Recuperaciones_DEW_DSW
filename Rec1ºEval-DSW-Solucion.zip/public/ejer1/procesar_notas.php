<?php
require_once "datos.php";
$error = "";
//- Si datos no vacios
if (!isset($_POST["alumno"]) || !isset($_POST["nota"])) {
    $error = "Faltan datos";
} elseif (empty($_POST["alumno"]) || $_POST["nota"] === "") {
    $error = "campos vacios";
}

$alumno = $_POST["alumno"];
$nota = $_POST["nota"];
//- Si alumno existe en array
if (!$error && !array_key_exists($alumno, $notasAlumnos)) {
    $error = "El alumno no existe.";
}
//- Si nota es numérico
if (!$error && !is_numeric($nota)) {
    $error = "La nota debe ser numérica.";
}
//- Si nota está entre 0 y 10
if (!$error && ($nota < 0 || $nota > 10)) {
    $error = "La nota debe estar entre 0 y 10.";
}

function calcularMedia(array $notas): float
{
    return array_sum($notas) / count($notas);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php if ($error): ?>
        <h3 style="color:red;">Error</h3>
        <p><?= $error ?></p>
        <a href="ejer1.php">Volver al formulario</a>
    <?php else: ?>
        <?php
        $notasAlumnos[$alumno][] = $nota;
        ?>
        <h3 style="color:green;">
            Nota <?= $nota ?> añadida a <?= $alumno ?>
        </h3>
        <h2>Listado de Notas</h2>
        <table border="1" cellpadding="5">
            <tr>
                <th>Alumno</th>
                <th>Notas</th>
                <th>Media</th>
            </tr>

            <?php foreach ($notasAlumnos as $nombre => $notas): ?>
                <tr>
                    <td><?= $nombre ?></td>
                    <td>
                        <?= implode(", ", $notas) ?>
                    </td>
                    <td>
                        <?= number_format(calcularMedia($notas), 2) ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
        <a href="ejer1.php">Volver</a>
    <?php endif; ?>
</body>

</html>
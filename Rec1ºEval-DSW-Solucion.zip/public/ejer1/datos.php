<?php
$notasAlumnos = [
    "Juan" => [5,6,7],
    "Ana" => [3,2,6],
    "Andres" => [7,9,8],
    "Pedro" => [6,9]
];
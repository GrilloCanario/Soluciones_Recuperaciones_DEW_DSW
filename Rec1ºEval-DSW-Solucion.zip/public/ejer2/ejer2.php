<?php
session_start();

//- Cookie para Tema

if (isset($_POST["tema"])) {
    setcookie(
        "tema",
        $_POST["tema"],
        time() + (7 * 24 * 60 * 60),
        "/"
    );
    header("Location: ejer2.php");
}

//- Tema por defecto
$tema = $_COOKIE["tema"] ?? "oscuro";

//- Sesion del Usuario

if (isset($_POST["nombre"])) {
    $_SESSION["usuario"] = $_POST["nombre"];
}

if (isset($_GET["logout"])) {
    session_destroy();
    header("Location: ejer2.php");
    exit;
}

$usuario = $_SESSION["usuario"] ?? null;

//- Cambio de CSS por Usuario
$css = ($tema === "oscuro") ? "css/oscuro.css" : "css/claro.css";

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="<?= $css ?>">
</head>

<body>
    <h1>Ejercicio 2</h1>
    <form method="POST">
        <button type="submit" name="tema" value="claro">Modo Claro</button>
        <button type="submit" name="tema" value="oscuro">Modo Oscuro</button>
    </form>
    <h2>Identidad</h2>
    <?php if (!$usuario): ?>
        <form method="POST">
            <label>Nombre:</label><br>
            <input type="text" name="nombre" required>
            <br>
            <button type="submit">Entrar</button>
        </form>
    <?php else: ?>
        <p>
            Hola, <strong><?= htmlspecialchars($usuario) ?></strong>,
            tu preferencia de fondo se ha cargado.
        </p>
        <a href="ejer2.php?logout=1">Cerrar sesión</a>
    <?php endif; ?>
</body>
</html>